#include<stdio.h>
#include<unistd.h>
#include<stdlib.h> //for atoi
#include<string.h>//for bzero
#include<sys/socket.h>//for sockets
#include<sys/types.h>
#include<sys/mman.h>//for mmap
#include<sys/stat.h>
#include<netinet/in.h>//for sockaddr_in
#include<netdb.h>//for gethostbyaddr
#include<arpa/inet.h>//for inet_ntoa
#include<fcntl.h>//for open file

void read_options(int argc,char **argv);
int response(int listenfd,int connfd);
int open_listenfd();
void cerror(FILE *stream,char *casue,char *errno,char *shortmsg,char *longmsg);
void error(char *msg);

int portno=8080;
FILE *stream;
struct sockaddr_in serveraddr;
struct sockaddr_in clientaddr;

#define BUFSIZE 1024

int main(int argc,char **argv){
	int listenfd,connfd;
	int clientlen;
	
	read_options(argc,argv);
	listenfd=open_listenfd();/*open bind listen and accept*/
	clientlen=sizeof(clientaddr);
	while(1){
		
		connfd=accept(listenfd,(struct sockaddr*)&clientaddr,&clientlen);
		if(connfd<0)
			error("Failed accepting...\n");
		if(fork()==0){//child process
			close(listenfd);
			if(response(listenfd,connfd)){/*get uri and determine filename open file and response*/
				error("Failed response\n");	
			}
			exit(0);
		}else 	close(connfd);
		/*clean up*/
		//fclose(stream);
		//close(connfd);
	}
	
	return 0;
}

int open_listenfd(){
	int listenfd;
	int optval;
	listenfd=socket(AF_INET,SOCK_STREAM,0);
	if(listenfd<0)
		error("Failed socket()");
	/*to restart server immediately*/
	optval=1;
	setsockopt(listenfd,SOL_SOCKET,SO_REUSEADDR,(const void*)&optval,sizeof(int));
	
	/*bind*/
	bzero((char *)&serveraddr,sizeof(serveraddr));
	serveraddr.sin_family=AF_INET;
	serveraddr.sin_addr.s_addr=htonl(INADDR_ANY);
	serveraddr.sin_port=htons((unsigned short)portno);
	if(bind(listenfd,(struct sockaddr*)&serveraddr,sizeof(serveraddr))<0)
		error("Failed binding");
	
	if(listen(listenfd,5)<0)
		error("falied listening");
	
	return listenfd;
	
}

int response(int listenfd,int connfd){
	
	struct hostent *hostp;
	char *hostaddrp;
	char *p;
	int fd;
	struct stat sbuf;
	int is_static;
	
	char buf[BUFSIZE];
	char filename[BUFSIZE];
	char filetype[BUFSIZE];
	char cgiargs[BUFSIZE];
	char method[BUFSIZE];
	char uri[BUFSIZE];
	char version[BUFSIZE];
	
	hostp=gethostbyaddr((const char*)&clientaddr.sin_addr.s_addr,sizeof(clientaddr.sin_addr.s_addr),AF_INET);
	if(hostp==NULL)
		error("falied on gethostbyaddr");
	hostaddrp=inet_ntoa(clientaddr.sin_addr);
	if(hostaddrp==NULL)
		error("failed on inet_ntoa");
	
	/*open stream and get http requset line*/
	if((stream=fdopen(connfd,"r+"))==NULL)
		error("failed on fdopen");
	
	fgets(buf,BUFSIZE,stream);
	printf("BUF:%s",buf);
	sscanf(buf,"%s %s %s\n",method,uri,version);
	printf("method %s uri %s version %s\n",method,uri,version);
	
	/*method validation*/
	if(strcasecmp(method,"GET")&&strcasecmp(method,"POST")){
		cerror(stream,method,"501","Not implemented","this web server dose not have this mthod");
		fclose(stream);
		close(connfd);
		return 1;
	}
	fgets(buf,BUFSIZE,stream);
	printf("BUF2:%s",buf);
	while(strcmp(buf,"\r\n")){
		fgets(buf,BUFSIZE,stream);
		printf("BUF3:%s",buf);
	}
	if(!strstr(uri,"www")){/*not www inside uri*/
		//is_static=1;
		strcpy(cgiargs,"");
		strcpy(filename,"../../www/");
		//strcat(filename,uri);
		//if(uri[strlen(uri)-1]=='/')
			strcat(filename,"index.html");
		printf("filename:%s \n",filename);
	}else{
		strcpy(filename,"../..");
		strcat(filename,uri);
		strcat(filename,".html");
	}
	
	if(stat(filename,&sbuf)<0){
		
		cerror(stream,filename,"404","Not found","Couldnt find this file");
		fclose(stream);
		close(connfd);
		return 1;
	}
	
//	if(is_static){/*static filetype*/
			if(strstr(filename,".html"))
				strcpy(filetype,"text/html");
			else if(strstr(filename,".gif"))
				strcpy(filetype,"image/gif");
			else if(strstr(filename,".jpg"))
				strcpy(filetype,"image/jpg");
			else 
				strcpy(filetype,"text/plain");
			
			
		fprintf(stream,"HTTP/1.1 200 OK\n");
		fprintf(stream,"Server:Slime Web Server\n");
		fprintf(stream,"Content-length:%d\n",(int)sbuf.st_size);
		fprintf(stream,"Content-type:%s\n",filetype);
		fprintf(stream,"\r\n");
		fflush(stream);
		
		
		fd=open(filename,O_RDONLY);
		p=mmap(0,sbuf.st_size,PROT_READ,MAP_PRIVATE,fd,0);
		fwrite(p,1,sbuf.st_size,stream);
		munmap(p,sbuf.st_size);
		
	//}
		fclose(stream);
		close(connfd);
		return 0;
		
		
		
	
}
/*read_options*/
void read_options(int argc,char **argv){
	char *prom;/*for error prompt*/
	prom=*argv;
	while(++argv,--argc>0){
		if(**argv == '-'){
			switch(*++*argv){
				/*print help text*/
				case 'h':
					printf("Usage:-h:help text,-p:assgin to which port number,-d:run as daemon,-l:log to logfile,-s:select request handling strategy\n");
					break;
				/*port number*/
				case 'p':
                    --argc;
					portno=atoi(*++argv);/*string array to int*/
					break;
				/*run as daemon*/
				case 'd':
                    printf("Not implented.\n");
					break;
				/*log to logfile*/
				case 'l':
					break;
				/*select cocurrent request handling strategy:fork/thread/prefork/mux*/
				case 's':
                    printf("Only one request handling method implemented!\n");
					break;
				default:
					printf("%s:ignored option:-%s",prom,*argv);/*then print usage*/
					printf("Usage:-h:help text,-p:assgin to which port number,-d:run as daemon,-l:log to logfile,-s:select request handling strategy\n");
			}
		}
	}
	
}
void error(char *msg){
	perror(msg);
	exit(1);
}
void cerror(FILE *stream,char *cause,char *errno,char *shortmsg,char *longmsg){
	fprintf(stream,"HTTP/1.1 %s %s",errno,shortmsg);
	fprintf(stream,"Content-type:text/html\n");
	fprintf(stream,"\n");
	fprintf(stream,"<html><title>ERROR!!!</title>");
	fprintf(stream,"<body bgcolor=""ffffff"">\n");
	fprintf(stream,"%s %s\n",errno,shortmsg);
	fprintf(stream,"<p>%s: %s\n",longmsg,cause);
	fprintf(stream,"<hr><em>The slim web server</em>\n");
}
